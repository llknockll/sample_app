# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'f2c28e3b73e104ec6537071b528755d9a2507220e4629d184743549d583e79eda7653581ec91ec8c3a3cde2ac2d2dfbd3c456813ceafb2c7f189bf52695e9f92'